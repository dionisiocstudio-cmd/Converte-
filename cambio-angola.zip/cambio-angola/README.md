# Câmbio Angola

App Android com câmbio do dia em kwanzas, conversor de 8 moedas, aba de doações e aba do desenvolvedor.

## 1. Personalizar
Abra `www/index.html` e edite o bloco `CONFIG` no início do script: dados bancários, carteiras crypto, redes sociais e nome do desenvolvedor.
Para usar a taxa oficial do BNA, preencha `bnaManual`, por exemplo `{USD: 912.5, EUR: 1010}`.

## 2. Testar no telemóvel (sem instalar nada)
Abra `www/index.html` no navegador do telemóvel. Funciona igual.

## 3. Gerar o APK
Requisitos: Node.js 18+ e Android Studio.

    npm install
    npx cap add android
    npx cap sync android
    npx cap open android

No Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
Para publicar na Play Store: Build > Generate Signed Bundle / APK.

Ícone do app: substitua os ficheiros em `android/app/src/main/res/mipmap-*`.

## Moedas
AOA, USD, EUR, BRL, CNY, GBP, RUB e ZAR. O dólar namibiano (NAD) tem paridade 1:1 com o rand sul-africano, por isso partilham a mesma entrada.

## Fonte das taxas
open.er-api.com (gratuita, sem chave). Se estiver sem internet, o app mostra as últimas taxas guardadas.

## Gerar o APK pelo GitHub (sem Android Studio)
1. Envie esta pasta para um repositório no GitHub (branch `main`).
2. Abra o separador **Actions** > **Build APK**. A compilação começa sozinha a cada envio, ou use **Run workflow**.
3. Quando terminar (cerca de 5 a 8 minutos), abra a execução e descarregue **cambio-angola-apk** em Artifacts.
4. Descompacte e instale `app-debug.apk` no telemóvel (permita instalar de fontes desconhecidas).
